# replit.md

## Overview

InnovateLab is a modern waitlist landing page application designed for an AI-powered innovation platform startup. The application serves as a marketing website with a sophisticated waitlist registration system, featuring a beautiful modern UI built with React, TypeScript, and Tailwind CSS. The system includes a public-facing landing page, waitlist functionality, and an admin dashboard for tracking registrations and analytics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built as a Single Page Application (SPA) using React 18 with TypeScript. The architecture follows a component-based design pattern with:

- **UI Framework**: Utilizes shadcn/ui components built on top of Radix UI primitives for accessibility and consistency
- **Styling**: Tailwind CSS with custom design tokens and animations for a modern glass-morphism aesthetic
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
The server follows a RESTful API pattern built with Express.js and TypeScript:

- **Web Framework**: Express.js with middleware for JSON parsing, CORS, and request logging
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Storage Pattern**: Repository pattern implemented through the `IStorage` interface for clean separation of concerns
- **API Design**: RESTful endpoints for waitlist operations with proper HTTP status codes and error handling
- **Development Server**: Integrated Vite development server for seamless full-stack development

### Data Storage Solutions
- **Primary Database**: PostgreSQL hosted on Neon (serverless PostgreSQL)
- **ORM**: Drizzle ORM with code-first schema definitions
- **Schema Management**: Database migrations handled through Drizzle Kit
- **Connection**: Neon serverless driver with WebSocket support for edge deployments

### Authentication and Authorization
Currently, the application implements a simple model without user authentication for the waitlist functionality. The admin dashboard is accessible without authentication (suitable for internal use or could be extended with proper auth).

### Database Schema
The application uses two main entities:
- **waitlist_registrations**: Stores user registration data including name, email, company, and preferences
- **users**: Basic user table (currently unused but available for future authentication features)

### API Endpoints
- `POST /api/waitlist`: Create new waitlist registration with validation
- `GET /api/waitlist`: Retrieve all registrations (admin endpoint)
- `GET /api/waitlist/stats`: Get registration statistics and metrics

## External Dependencies

### Third-party Services
- **Neon Database**: Serverless PostgreSQL database hosting with automatic scaling
- **Unsplash**: Image hosting for high-quality stock photography used in the UI

### Key Libraries and Frameworks
- **Frontend**: React, TypeScript, Vite, TanStack Query, React Hook Form, Wouter
- **UI Components**: shadcn/ui, Radix UI primitives, Tailwind CSS, Lucide React icons
- **Backend**: Express.js, TypeScript, tsx for development
- **Database**: Drizzle ORM, @neondatabase/serverless, connect-pg-simple
- **Validation**: Zod for runtime type checking and form validation
- **Build Tools**: esbuild for production builds, PostCSS for CSS processing
- **Development**: Replit-specific plugins for development environment integration

### Font and Asset Dependencies
- **Google Fonts**: Inter font family for modern typography
- **Icons**: Lucide React for consistent iconography
- **Images**: Unsplash API for professional stock photography

The application is designed to be deployed on platforms like Replit, Vercel, or any Node.js hosting environment with PostgreSQL database support.