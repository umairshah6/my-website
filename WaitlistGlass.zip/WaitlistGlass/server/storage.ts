import { waitlistRegistrations, type WaitlistRegistration, type InsertWaitlistRegistration, type User, type InsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createWaitlistRegistration(registration: InsertWaitlistRegistration): Promise<WaitlistRegistration>;
  getAllWaitlistRegistrations(): Promise<WaitlistRegistration[]>;
  getWaitlistRegistrationByEmail(email: string): Promise<WaitlistRegistration | undefined>;
  getWaitlistStats(): Promise<{ totalRegistrations: number; todayRegistrations: number }>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(waitlistRegistrations).where(eq(waitlistRegistrations.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // This method is not implemented for the current use case
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    // This method is not implemented for the current use case
    return user;
  }

  async createWaitlistRegistration(registration: InsertWaitlistRegistration): Promise<WaitlistRegistration> {
    const [newRegistration] = await db
      .insert(waitlistRegistrations)
      .values(registration)
      .returning();
    return newRegistration;
  }

  async getAllWaitlistRegistrations(): Promise<WaitlistRegistration[]> {
    return await db
      .select()
      .from(waitlistRegistrations)
      .orderBy(desc(waitlistRegistrations.createdAt));
  }

  async getWaitlistRegistrationByEmail(email: string): Promise<WaitlistRegistration | undefined> {
    const [registration] = await db
      .select()
      .from(waitlistRegistrations)
      .where(eq(waitlistRegistrations.email, email));
    return registration || undefined;
  }

  async getWaitlistStats(): Promise<{ totalRegistrations: number; todayRegistrations: number }> {
    const [totalResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(waitlistRegistrations);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const [todayResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(waitlistRegistrations)
      .where(sql`${waitlistRegistrations.createdAt} >= ${today}`);

    return {
      totalRegistrations: totalResult.count || 0,
      todayRegistrations: todayResult.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
