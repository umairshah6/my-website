import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistRegistrationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Create waitlist registration
  app.post("/api/waitlist", async (req, res) => {
    try {
      const validatedData = insertWaitlistRegistrationSchema.parse(req.body);
      
      // Check if email already exists
      const existingRegistration = await storage.getWaitlistRegistrationByEmail(validatedData.email);
      if (existingRegistration) {
        return res.status(409).json({ message: "Email already registered" });
      }
      
      const registration = await storage.createWaitlistRegistration(validatedData);
      res.status(201).json({ 
        message: "Successfully joined the waitlist",
        registration: { 
          id: registration.id,
          firstName: registration.firstName,
          email: registration.email 
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error",
          errors: error.errors.map(e => ({
            field: e.path.join('.'),
            message: e.message
          }))
        });
      }
      console.error("Error creating waitlist registration:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all waitlist registrations (admin endpoint)
  app.get("/api/waitlist", async (req, res) => {
    try {
      const registrations = await storage.getAllWaitlistRegistrations();
      res.json(registrations);
    } catch (error) {
      console.error("Error fetching waitlist registrations:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get waitlist stats
  app.get("/api/waitlist/stats", async (req, res) => {
    try {
      const stats = await storage.getWaitlistStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching waitlist stats:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
