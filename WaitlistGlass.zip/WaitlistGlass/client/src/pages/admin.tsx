import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Users, TrendingUp, Calendar } from "lucide-react";
import type { WaitlistRegistration } from "@shared/schema";
import { Link } from "wouter";

interface WaitlistStats {
  totalRegistrations: number;
  todayRegistrations: number;
}

export default function Admin() {
  const { data: registrations, isLoading: isLoadingRegistrations } = useQuery<WaitlistRegistration[]>({
    queryKey: ['/api/waitlist']
  });

  const { data: stats, isLoading: isLoadingStats } = useQuery<WaitlistStats>({
    queryKey: ['/api/waitlist/stats']
  });

  const handleExportData = () => {
    if (!registrations || registrations.length === 0) return;

    const csvHeaders = ['Name', 'Email', 'Company', 'Date', 'Updates'];
    const csvData = registrations.map(reg => [
      `${reg.firstName} ${reg.lastName}`,
      reg.email,
      reg.company || '',
      new Date(reg.createdAt!).toLocaleDateString(),
      reg.wantsUpdates ? 'Yes' : 'No'
    ]);

    const csvContent = [csvHeaders, ...csvData]
      .map(row => row.map(field => `"${field}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('href', url);
    a.setAttribute('download', `waitlist-registrations-${new Date().toISOString().split('T')[0]}.csv`);
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const growthRate = stats && stats.totalRegistrations > 0 
    ? Math.round((stats.todayRegistrations / stats.totalRegistrations) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-indigo-900">
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2" data-testid="admin-title">Waitlist Admin Dashboard</h1>
            <p className="text-white/60">Manage and monitor waitlist registrations</p>
          </div>
          <Link href="/" data-testid="link-home">
            <Button variant="outline" className="text-white border-white/20 hover:bg-white/10">
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="glass-dark rounded-2xl p-8">
          <h2 className="text-2xl font-bold mb-8 text-white" data-testid="text-registrations-title">Waitlist Registrations</h2>
          
          {/* Stats Cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="glass border-white/10" data-testid="card-total-stats">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users className="h-6 w-6 text-white mr-2" />
                  <div className="text-3xl font-bold text-white">
                    {isLoadingStats ? '...' : (stats?.totalRegistrations || 0)}
                  </div>
                </div>
                <div className="text-white/60">Total Registrations</div>
              </CardContent>
            </Card>

            <Card className="glass border-white/10" data-testid="card-today-stats">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-2">
                  <Calendar className="h-6 w-6 text-emerald-400 mr-2" />
                  <div className="text-3xl font-bold text-emerald-400">
                    {isLoadingStats ? '...' : (stats?.todayRegistrations || 0)}
                  </div>
                </div>
                <div className="text-white/60">Today</div>
              </CardContent>
            </Card>

            <Card className="glass border-white/10" data-testid="card-growth-stats">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-2">
                  <TrendingUp className="h-6 w-6 text-blue-400 mr-2" />
                  <div className="text-3xl font-bold text-blue-400">
                    +{growthRate}%
                  </div>
                </div>
                <div className="text-white/60">Growth Rate</div>
              </CardContent>
            </Card>
          </div>

          {/* Registrations Table */}
          <Card className="glass border-white/10" data-testid="card-registrations-table">
            <CardHeader className="border-b border-white/10">
              <CardTitle className="text-xl text-white">Recent Registrations</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                {isLoadingRegistrations ? (
                  <div className="p-8 text-center text-white/60">Loading registrations...</div>
                ) : !registrations || registrations.length === 0 ? (
                  <div className="p-8 text-center text-white/60" data-testid="text-no-registrations">
                    No registrations yet
                  </div>
                ) : (
                  <table className="w-full text-left">
                    <thead className="text-white/60 bg-black/20">
                      <tr>
                        <th className="px-6 py-4 font-medium">Name</th>
                        <th className="px-6 py-4 font-medium">Email</th>
                        <th className="px-6 py-4 font-medium">Company</th>
                        <th className="px-6 py-4 font-medium">Date</th>
                        <th className="px-6 py-4 font-medium">Updates</th>
                      </tr>
                    </thead>
                    <tbody className="text-white">
                      {registrations.map((registration) => (
                        <tr key={registration.id} className="border-b border-white/10" data-testid={`row-registration-${registration.id}`}>
                          <td className="px-6 py-4" data-testid={`text-name-${registration.id}`}>
                            {registration.firstName} {registration.lastName}
                          </td>
                          <td className="px-6 py-4" data-testid={`text-email-${registration.id}`}>
                            {registration.email}
                          </td>
                          <td className="px-6 py-4" data-testid={`text-company-${registration.id}`}>
                            {registration.company || '-'}
                          </td>
                          <td className="px-6 py-4" data-testid={`text-date-${registration.id}`}>
                            {new Date(registration.createdAt!).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4">
                            <span 
                              className={`px-2 py-1 rounded-full text-xs ${
                                registration.wantsUpdates 
                                  ? 'bg-emerald-600/20 text-emerald-400' 
                                  : 'bg-slate-600/20 text-slate-400'
                              }`}
                              data-testid={`status-updates-${registration.id}`}
                            >
                              {registration.wantsUpdates ? 'Yes' : 'No'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Export Button */}
          {registrations && registrations.length > 0 && (
            <div className="mt-6 text-center">
              <Button 
                onClick={handleExportData}
                className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white hover:from-blue-600 hover:to-indigo-700"
                data-testid="button-export"
              >
                <Download className="mr-2 h-4 w-4" />
                Export Data
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
