import { useState, useEffect } from "react";
import { Box, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [navBackground, setNavBackground] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      setNavBackground(scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        navBackground 
          ? 'bg-black/90 backdrop-blur-lg' 
          : 'bg-black/10 backdrop-blur-sm'
      }`}
      data-testid="navigation"
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-3" data-testid="link-logo">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <Box className="text-white text-sm" size={16} />
            </div>
            <h1 className="text-xl font-bold text-white">InnovateLab</h1>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('about')}
              className="text-white/80 hover:text-white transition duration-300"
              data-testid="button-nav-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('features')}
              className="text-white/80 hover:text-white transition duration-300"
              data-testid="button-nav-features"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('waitlist')}
              className="text-white/80 hover:text-white transition duration-300"
              data-testid="button-nav-waitlist"
            >
              Join Waitlist
            </button>
            <Link href="/admin" data-testid="link-admin">
              <Button variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10">
                Admin
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white"
            onClick={toggleMenu}
            data-testid="button-mobile-menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-white/20" data-testid="mobile-menu">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('about')}
                className="text-white/80 hover:text-white transition duration-300 text-left"
                data-testid="button-mobile-about"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="text-white/80 hover:text-white transition duration-300 text-left"
                data-testid="button-mobile-features"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('waitlist')}
                className="text-white/80 hover:text-white transition duration-300 text-left"
                data-testid="button-mobile-waitlist"
              >
                Join Waitlist
              </button>
              <Link href="/admin" data-testid="link-mobile-admin">
                <Button variant="ghost" className="text-white/80 hover:text-white hover:bg-white/10 w-full justify-start">
                  Admin
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
