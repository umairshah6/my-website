import { Brain, Users, Rocket } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface WaitlistStats {
  totalRegistrations: number;
  todayRegistrations: number;
}

export default function AboutSection() {
  const { data: stats } = useQuery<WaitlistStats>({
    queryKey: ['/api/waitlist/stats']
  });

  const customers = Math.floor((stats?.totalRegistrations || 0) / 6) + 50; // Derived metric
  const countries = Math.min(50, Math.floor((stats?.totalRegistrations || 0) / 20) + 15); // Derived metric
  const innovations = Math.floor((stats?.totalRegistrations || 0) * 3.5) + 1000; // Derived metric

  return (
    <section id="about" className="py-24 bg-white relative" data-testid="about-section">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-600">
            <h2 className="text-4xl md:text-5xl font-black mb-8 text-slate-900" data-testid="about-title">
              Revolutionizing How
              <span className="gradient-text"> Teams Innovate</span>
            </h2>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed" data-testid="about-description">
              InnovateLab is the world's first AI-powered innovation platform that transforms how organizations 
              discover, develop, and deploy breakthrough solutions. Our proprietary technology combines machine 
              learning, collaborative intelligence, and real-time market insights.
            </p>
            <div className="space-y-6">
              <div className="flex items-start space-x-4" data-testid="feature-ai">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <Brain className="text-blue-600" size={18} />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-2">AI-Powered Insights</h3>
                  <p className="text-slate-600">Advanced algorithms analyze market trends and predict innovation opportunities.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4" data-testid="feature-collaboration">
                <div className="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <Users className="text-indigo-600" size={18} />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-2">Collaborative Workspace</h3>
                  <p className="text-slate-600">Seamless collaboration tools designed for distributed innovation teams.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4" data-testid="feature-prototyping">
                <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                  <Rocket className="text-emerald-600" size={18} />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-2">Rapid Prototyping</h3>
                  <p className="text-slate-600">From idea to prototype in days, not months, with our integrated development suite.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-600" style={{ animationDelay: '0.2s' }}>
            <div className="relative" data-testid="about-image">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Professional business team collaborating" 
                className="rounded-2xl shadow-2xl w-full"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600/20 to-transparent rounded-2xl"></div>
              
              {/* Glass overlay stats */}
              <div className="absolute bottom-6 left-6 right-6">
                <div className="glass rounded-xl p-6 text-white" data-testid="stats-overlay">
                  <div className="flex justify-between items-center">
                    <div className="text-center" data-testid="stat-customers">
                      <div className="text-2xl font-bold">{customers}+</div>
                      <div className="text-sm opacity-80">Enterprise Clients</div>
                    </div>
                    <div className="text-center" data-testid="stat-countries">
                      <div className="text-2xl font-bold">{countries}+</div>
                      <div className="text-sm opacity-80">Countries</div>
                    </div>
                    <div className="text-center" data-testid="stat-innovations">
                      <div className="text-2xl font-bold">{innovations.toLocaleString()}+</div>
                      <div className="text-sm opacity-80">Innovations</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
