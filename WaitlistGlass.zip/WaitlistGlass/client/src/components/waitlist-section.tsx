import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { Lock, Mail, Gift, CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const waitlistSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  company: z.string().optional(),
  wantsUpdates: z.boolean().default(false)
});

type WaitlistForm = z.infer<typeof waitlistSchema>;

export default function WaitlistSection() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<WaitlistForm>({
    resolver: zodResolver(waitlistSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      company: "",
      wantsUpdates: false
    }
  });

  const waitlistMutation = useMutation({
    mutationFn: async (data: WaitlistForm) => {
      return await apiRequest('POST', '/api/waitlist', data);
    },
    onSuccess: () => {
      setIsSubmitted(true);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/waitlist/stats'] });
      toast({
        title: "Welcome aboard!",
        description: "We'll keep you updated on our progress.",
      });
    },
    onError: (error: Error) => {
      const errorMessage = error.message.includes('Email already registered') 
        ? "This email is already on our waitlist!" 
        : "Something went wrong. Please try again.";
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: WaitlistForm) => {
    waitlistMutation.mutate(data);
  };

  return (
    <section id="waitlist" className="py-24 bg-gradient-to-br from-slate-900 to-indigo-900 relative overflow-hidden" data-testid="waitlist-section">
      {/* Modern startup office background */}
      <div className="absolute inset-0 opacity-10">
        <img 
          src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Modern startup office with innovative technology setup" 
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <div className="animate-on-scroll opacity-0 translate-y-8 transition-all duration-600">
          <h2 className="text-4xl md:text-5xl font-black mb-8 text-white" data-testid="waitlist-title">
            Ready to Transform Your
            <span className="gradient-text"> Innovation Process?</span>
          </h2>
          <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto leading-relaxed" data-testid="waitlist-description">
            Join the waitlist today and be among the first to experience the future of innovation management. 
            Early access includes exclusive onboarding and special pricing.
          </p>

          {/* Waitlist Form */}
          <div className="glass rounded-2xl p-8 md:p-12 max-w-2xl mx-auto" data-testid="waitlist-form-container">
            {isSubmitted ? (
              <div className="text-center" data-testid="success-message">
                <div className="flex items-center justify-center text-emerald-300 mb-4">
                  <CheckCircle className="mr-2" size={24} />
                  <span className="text-lg font-semibold">Welcome aboard!</span>
                </div>
                <p className="text-white/80">We'll keep you updated on our progress.</p>
              </div>
            ) : (
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="waitlist-form">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="firstName" className="block text-sm font-medium text-white/90 mb-2 text-left">
                      First Name
                    </Label>
                    <Input
                      id="firstName"
                      {...form.register("firstName")}
                      type="text"
                      placeholder="John"
                      className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                      data-testid="input-first-name"
                    />
                    {form.formState.errors.firstName && (
                      <span className="text-red-400 text-sm mt-1 block" data-testid="error-first-name">
                        {form.formState.errors.firstName.message}
                      </span>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="lastName" className="block text-sm font-medium text-white/90 mb-2 text-left">
                      Last Name
                    </Label>
                    <Input
                      id="lastName"
                      {...form.register("lastName")}
                      type="text"
                      placeholder="Doe"
                      className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                      data-testid="input-last-name"
                    />
                    {form.formState.errors.lastName && (
                      <span className="text-red-400 text-sm mt-1 block" data-testid="error-last-name">
                        {form.formState.errors.lastName.message}
                      </span>
                    )}
                  </div>
                </div>

                <div>
                  <Label htmlFor="email" className="block text-sm font-medium text-white/90 mb-2 text-left">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    {...form.register("email")}
                    type="email"
                    placeholder="john@company.com"
                    className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                    data-testid="input-email"
                  />
                  {form.formState.errors.email && (
                    <span className="text-red-400 text-sm mt-1 block" data-testid="error-email">
                      {form.formState.errors.email.message}
                    </span>
                  )}
                </div>

                <div>
                  <Label htmlFor="company" className="block text-sm font-medium text-white/90 mb-2 text-left">
                    Company (Optional)
                  </Label>
                  <Input
                    id="company"
                    {...form.register("company")}
                    type="text"
                    placeholder="Your Company"
                    className="w-full px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                    data-testid="input-company"
                  />
                </div>

                <div className="text-left">
                  <div className="flex items-start space-x-3">
                    <Checkbox 
                      id="updates"
                      {...form.register("wantsUpdates")}
                      className="mt-1 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                      data-testid="checkbox-updates"
                    />
                    <Label htmlFor="updates" className="text-sm text-white/80 leading-relaxed cursor-pointer">
                      I'd like to receive updates about InnovateLab's progress, exclusive content, and early access opportunities. (You can unsubscribe anytime)
                    </Label>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  disabled={waitlistMutation.isPending}
                  className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-4 px-8 rounded-xl font-semibold text-lg hover:from-blue-600 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-transparent transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed h-auto"
                  data-testid="button-submit"
                >
                  {waitlistMutation.isPending ? (
                    <span>Joining...</span>
                  ) : (
                    <>
                      <span>Join the Waitlist</span>
                      <ArrowRight className="ml-2" size={20} />
                    </>
                  )}
                </Button>
              </form>
            )}

            <div className="mt-8 flex flex-wrap justify-center items-center space-x-8 text-white/60 text-sm">
              <div className="flex items-center space-x-2" data-testid="security-badge">
                <Lock className="text-emerald-400" size={16} />
                <span>Your data is secure</span>
              </div>
              <div className="flex items-center space-x-2" data-testid="no-spam-badge">
                <Mail className="text-blue-400" size={16} />
                <span>No spam, ever</span>
              </div>
              <div className="flex items-center space-x-2" data-testid="perks-badge">
                <Gift className="text-purple-400" size={16} />
                <span>Early access perks</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Background Glass Elements */}
      <div className="absolute top-20 left-10 animate-float opacity-20 hidden lg:block" style={{ animationDelay: '0s' }}>
        <div className="glass w-24 h-24 rounded-2xl"></div>
      </div>
      <div className="absolute bottom-32 right-16 animate-float opacity-20 hidden lg:block" style={{ animationDelay: '3s' }}>
        <div className="glass w-16 h-16 rounded-xl"></div>
      </div>
    </section>
  );
}
