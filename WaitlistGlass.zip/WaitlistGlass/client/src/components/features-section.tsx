import { Cpu, Shield, BarChart3, Plug, Smartphone, Headphones, ArrowRight } from "lucide-react";

const features = [
  {
    icon: Cpu,
    title: "Smart Automation",
    description: "Automate repetitive tasks and focus on high-impact innovation work with our intelligent workflow engine.",
    gradient: "from-blue-500 to-indigo-600"
  },
  {
    icon: Shield,
    title: "Enterprise Security",
    description: "Bank-grade security with SOC 2 compliance, end-to-end encryption, and advanced access controls.",
    gradient: "from-indigo-500 to-purple-600"
  },
  {
    icon: BarChart3,
    title: "Real-time Analytics",
    description: "Track innovation metrics, measure impact, and make data-driven decisions with comprehensive dashboards.",
    gradient: "from-emerald-500 to-teal-600"
  },
  {
    icon: Plug,
    title: "API Integration",
    description: "Connect with 100+ tools your team already uses through our robust API and webhook system.",
    gradient: "from-orange-500 to-red-600"
  },
  {
    icon: Smartphone,
    title: "Mobile First",
    description: "Native mobile apps for iOS and Android ensure your team can innovate from anywhere, anytime.",
    gradient: "from-pink-500 to-rose-600"
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description: "Dedicated customer success team with average response time under 2 hours for all support requests.",
    gradient: "from-cyan-500 to-blue-600"
  }
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 bg-slate-50 relative overflow-hidden" data-testid="features-section">
      {/* Glass technology elements background */}
      <div className="absolute inset-0 opacity-5">
        <img 
          src="https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Glass technology elements and digital interfaces" 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="relative max-w-7xl mx-auto px-6">
        <div className="text-center mb-20 animate-on-scroll opacity-0 translate-y-8 transition-all duration-600">
          <h2 className="text-4xl md:text-5xl font-black mb-6 text-slate-900" data-testid="features-title">
            Why Choose <span className="gradient-text">InnovateLab</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto" data-testid="features-description">
            Experience the next generation of innovation management with features designed 
            for the modern digital workspace.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className="glass rounded-2xl p-8 hover:bg-white/20 transition-all duration-300 group animate-on-scroll opacity-0 translate-y-8"
              style={{ animationDelay: `${index * 0.1}s` }}
              data-testid={`feature-card-${index}`}
            >
              <div className={`w-12 h-12 bg-gradient-to-r ${feature.gradient} rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="text-white" size={24} />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-slate-900" data-testid={`feature-title-${index}`}>
                {feature.title}
              </h3>
              <p className="text-slate-600 mb-6" data-testid={`feature-description-${index}`}>
                {feature.description}
              </p>
              <button className="inline-flex items-center text-blue-600 font-medium hover:text-blue-700 transition-colors" data-testid={`feature-link-${index}`}>
                Learn more <ArrowRight className="ml-2" size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
