import { Button } from "@/components/ui/button";
import { Rocket, Play, Users, Star, Shield, ArrowRight } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface WaitlistStats {
  totalRegistrations: number;
  todayRegistrations: number;
}

export default function HeroSection() {
  const { data: stats } = useQuery<WaitlistStats>({
    queryKey: ['/api/waitlist/stats']
  });

  const scrollToWaitlist = () => {
    const element = document.getElementById('waitlist');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center hero-bg" data-testid="hero-section">
      {/* Modern startup office background */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
          alt="Modern startup office with glass elements" 
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/50 to-indigo-900/30"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 text-center">
        <div className="animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
          <div className="inline-flex items-center px-4 py-2 rounded-full glass text-white/90 text-sm font-medium mb-8" data-testid="status-badge">
            <Rocket className="mr-2" size={16} />
            <span>Launching Q2 2024</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-black mb-8 leading-tight" data-testid="hero-title">
            <span className="text-white">The Future of</span><br />
            <span className="gradient-text">Innovation</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-white/80 mb-12 max-w-4xl mx-auto leading-relaxed" data-testid="hero-description">
            Join thousands of forward-thinking professionals revolutionizing the way teams collaborate, 
            innovate, and scale their breakthrough ideas with our cutting-edge platform.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Button 
              onClick={scrollToWaitlist}
              className="group bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 transform hover:scale-105 shadow-2xl h-auto"
              data-testid="button-join-waitlist"
            >
              <span>Join the Waitlist</span>
              <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
            </Button>
            <Button 
              variant="ghost"
              className="glass text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-white/20 transition-all duration-300 h-auto"
              data-testid="button-watch-demo"
            >
              <Play className="mr-2" size={20} />
              Watch Demo
            </Button>
          </div>
          
          <div className="mt-16 flex flex-wrap justify-center items-center space-x-8 text-white/60">
            <div className="flex items-center space-x-2" data-testid="stat-waitlist">
              <Users className="text-emerald-400" size={20} />
              <span>
                <span className="font-semibold">{stats?.totalRegistrations || 0}</span> people waiting
              </span>
            </div>
            <div className="flex items-center space-x-2" data-testid="stat-backing">
              <Star className="text-yellow-400" size={20} />
              <span>Backed by top VCs</span>
            </div>
            <div className="flex items-center space-x-2" data-testid="stat-enterprise">
              <Shield className="text-blue-400" size={20} />
              <span>Enterprise ready</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Floating Elements */}
      <div className="absolute top-1/4 left-10 animate-float hidden lg:block" style={{ animationDelay: '0s' }}>
        <div className="glass w-16 h-16 rounded-2xl flex items-center justify-center">
          <div className="w-6 h-6 bg-yellow-400 rounded-lg"></div>
        </div>
      </div>
      <div className="absolute top-1/3 right-10 animate-float hidden lg:block" style={{ animationDelay: '2s' }}>
        <div className="glass w-20 h-20 rounded-2xl flex items-center justify-center">
          <div className="w-8 h-8 bg-emerald-400 rounded-lg"></div>
        </div>
      </div>
      <div className="absolute bottom-1/4 left-1/4 animate-float hidden lg:block" style={{ animationDelay: '4s' }}>
        <div className="glass w-12 h-12 rounded-xl flex items-center justify-center">
          <div className="w-4 h-4 bg-indigo-400 rounded-full"></div>
        </div>
      </div>
    </section>
  );
}
